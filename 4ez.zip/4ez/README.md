# 4EZ-Media
Simple website created for a photography company in Collingdale, Pennsylvania
